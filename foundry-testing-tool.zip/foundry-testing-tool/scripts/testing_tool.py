import subprocess

def run_forge_tests():
    """Run Foundry tests and return the results."""
    result = subprocess.run(["forge", "test"], capture_output=True, text=True)
    return result.stdout

def run_gas_snapshot():
    """Generate gas snapshots to analyze contract gas usage."""
    result = subprocess.run(["forge", "snapshot"], capture_output=True, text=True)
    return result.stdout

def run_fuzzing():
    """Execute fuzzing tests on smart contracts."""
    result = subprocess.run(["forge", "test", "--fuzz-runs", "1000"], capture_output=True, text=True)
    return result.stdout

if __name__ == "__main__":
    print("Running Foundry Testing & Debugging Tool...\n")
    
    print("--- Running Forge Tests ---")
    print(run_forge_tests())
    
    print("--- Running Gas Snapshot ---")
    print(run_gas_snapshot())
    
    print("--- Running Fuzzing Tests ---")
    print(run_fuzzing())
