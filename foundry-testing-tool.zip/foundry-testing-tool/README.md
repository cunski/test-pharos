# Foundry Testing & Debugging Tool

## Struktur Repositori

```
foundry-testing-tool/
├── contracts/        # Smart contracts to be tested
│   ├── Example.sol   # Example smart contract
├── test/             # Foundry test scripts
│   ├── Example.t.sol # Test file for Example.sol
├── scripts/          # Python automation scripts
│   ├── testing_tool.py # Main testing script
├── .gitignore        # Ignore unnecessary files
├── README.md         # Documentation
```

## Deskripsi Skrip Testing

### `scripts/testing_tool.py`
Skrip ini menjalankan berbagai proses debugging dan optimasi pada smart contract menggunakan Foundry:

- **Simulasi Transaksi** → `forge test`
- **Snapshot Gas** → `forge snapshot`
- **Fuzzing** → `forge test --fuzz-runs 1000`

## Cara Menggunakan

1. **Clone Repository:**
   ```bash
   git clone https://github.com/username/foundry-testing-tool.git
   cd foundry-testing-tool
   ```
2. **Pastikan Foundry Sudah Terinstall:**
   ```bash
   curl -L https://foundry.paradigm.xyz | bash
   foundryup
   ```
3. **Jalankan Skrip Python:**
   ```bash
   python scripts/testing_tool.py
   ```

## Kontribusi

Pull request dipersilakan! Pastikan untuk menulis tes yang relevan sebelum mengirimkan perubahan.

---

🚀 Semoga bermanfaat untuk debugging dan optimasi smart contract-mu!
